package com.example.customer;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnector {

    public static Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/cuustomer_relationship_management";
        String username = "root";
        String password = "Nswetha@2004";
//        Class.forName()

        return DriverManager.getConnection(url, username, password);
    }
}
