package com.example.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class LooginController {


    @FXML
    private Button swetha;

    @FXML

        void Submit(ActionEvent event) {
            try {
                FXMLLoader loader=new FXMLLoader(getClass().getResource("Customer1.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
    }


}