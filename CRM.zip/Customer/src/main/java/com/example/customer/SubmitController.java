package com.example.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class SubmitController {

    @FXML
    private Button prathi;

    @FXML
    void Submit(ActionEvent event) {
        try {
            FXMLLoader loader=new FXMLLoader(getClass().getResource("Payment1.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            stage.show();

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
