package com.example.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class HelloController {
    @FXML
    private TextField email;

    @FXML
    private TextField Pass;

    @FXML
    void Login(ActionEvent event) throws IOException, SQLException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("extradetails.fxml"));
        Scene firstscene = new Scene(fxmlLoader.load());

        String email_id = email.getText();
        String Password = Pass.getText();
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cuustomer_relationship_management", "root","Nswetha@2004");
        String sql = "insert into login values (?,?)";
        PreparedStatement statement1 = connection.prepareStatement(sql);
        statement1.setString(1,email_id);
        statement1.setString(2,Password);
        statement1.execute();


        Stage stage = new Stage();
        stage.setTitle("ExtraDetails");
        stage.setScene(firstscene);
        stage.show();
    }

}