package com.example.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Second {

    @FXML
    private TextArea address;

    @FXML
    private TextField email;

    @FXML
    private TextField firstname;

    @FXML
    private TextField gender;

    @FXML
    private TextField lastname;

    @FXML
    private TextField mobileno;

    @FXML
    private TextField role;


    @FXML
        void Submit(ActionEvent event) throws IOException, SQLException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Customer1.fxml"));
        Scene firstscene = new Scene(fxmlLoader.load());
            String FirstName1 =firstname.getText();
            String Lastname1= lastname.getText();
            String Mobileno1= mobileno.getText();
            String Email1= email.getText();
            String Gender1= gender.getText();
            String Role1= role.getText();
            String Address1= address.getText();

            System.out.println(FirstName1 + "," + Lastname1 + "," + Mobileno1 + "," + Email1);

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cuustomer_relationship_management", "root", "Nswetha@2004");
        String sql = "INSERT INTO  extradetails values (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement1 = connection.prepareStatement(sql);
        statement1.setString(1, FirstName1);
        statement1.setString(2, Lastname1);
        statement1.setString(3, Mobileno1);
        statement1.setString(4, Email1);
        statement1.setString(5, Gender1);
        statement1.setString(6, Role1);
        statement1.setString(7, Address1);
//        Connection connection1  = DriverManager.getConnection("jdbc:mysql://localhost:3306/cuustomer_relationship_management", "root", "Nswetha@2004");
        if (connection!= null) {
            System.out.println("Connected to the database!");
        } else {
            System.out.println("Failed to connect to the database.");
        }
//        connection.commit();

        statement1.execute();

            Stage stage = new Stage();
            stage.setTitle("customer");
            stage.setScene(firstscene);
            stage.show();
        }

    }


