package com.example.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


    public class third {
        @FXML
        private TextArea feedback;
        @FXML
        private TextField productcode;

        @FXML
        private TextField personname;

        @FXML
        void Submit(ActionEvent event) throws IOException, SQLException {

//            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Payment.fxml"));
//            Scene firstscene = new Scene(fxmlLoader.load());
            System.out.println("feedbacks");
            String productcode1 = productcode.getText();
            String personname1 = personname.getText();
            String feedback1 = feedback.getText();
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cuustomer_relationship_management", "root", "Nswetha@2004");
            String sql = "insert into feedback values (?,?,?)";
            PreparedStatement statement1 = connection.prepareStatement(sql);
            statement1.setString(1, productcode1);
            statement1.setString(2, personname1);
            statement1.setString(3, feedback1);

            statement1.execute();
//            Stage stage = new Stage();
//            stage.setTitle("feedback");
//            stage.setScene(firstscene);
//            stage.show();
        }
    }